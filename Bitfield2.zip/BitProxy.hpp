/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#ifndef BIT_PROXY_HPP
#define BIT_PROXY_HPP

#include <cstddef>

//-----------------------------------------------------------------------------
//! Helper class used to represent a bit in a bitfield.
/*!
   \param T    Unsigned integer type of the word containing the bit
   \param R    Reference type of the word containing the bit
*/
template <class T, class R>
class BitProxy
{
public:
   //! Contructor
   BitProxy(R field, std::size_t index) :  field_(field), index_(index) {}

   //! Assignment
   BitProxy& operator=(bool state)
   {
      field_ = (field_ & ~(1 << index_)) | (state << index_);
      return *this;
   }

   //! Returns bit value
   operator bool() const {return (field_ & (1 << index_)) != 0;}

   //! Returns inverted bit value
   bool operator~() const {return !(static_cast<bool>(*this));}

private:
   R field_;
   const std::size_t index_;
};

#endif   // #ifndef BIT_PROXY_HPP

/*--------------------------------END OF FILE -------------------------------*/
