/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

//-----------------------------------------------------------------------------
// Used to access a memory-mapped I/O port
template <class T, std::size_t B, std::size_t O>
class Port
{
public:
   //! Value type
   typedef T ValueT;

   //! Traits
   enum
   {
      BASE = B,   //!< Base address
      OFFSET = O  //!< Offset between channels
   };

   //! Default constructor
   Port() : ref_(*(reinterpret_cast<volatile T*>(BASE))) {}

   //! Constructor taking a channel number
   Port(std::size_t channel)
   :  ref_(*(reinterpret_cast<volatile T*>(B + OFFSET*channel))) {}

   //! Write to port
   Port& operator=(ValT rhs) {ref_ = rhs;}

   //! Read from port
   operator ValT() const {return ref_;}

   //! Access port of the given channel
   Port operator[](std::size_t channel) const {return Port(channel);}

   //! Read from port and return inverted bits
   ValT operator~() const {return ~ref_;}

   //! Logically AND port bits
   Port& operator&=(ValT rhs) {ref_ &= rhs; return *this;}

   //! Logically OR port bits
   Port& operator|=(ValT rhs) {ref_ |= rhs; return *this;}

   //! Logically XOR port bits
   Port& operator^=(ValT rhs) {ref_ ^= rhs; return *this;}

private:
   Port(const Port&) {} // non-copyable
   volatile T& ref_;
};

// Example of defining an I/O register including bitfields
template <std::size_t CHANNEL = 0>
struct Uart
{
   typedef uint8_t ValueT;
   enum
   {
      BASE = 0x000002e8 + CHANNEL*0x10,
   };

   struct Lcr
   {
      enum {ADDR = BASE + 3};
      typedef Port<ValueT, ADDR, OFFSET> PortT;
      typedef cutl::Bitfield<0, 1, ValueT, PortT> Data;
      typedef cutl::Bitfield<2, 2, ValueT, PortT> Stop;
      typedef cutl::Bitfield<3, 5, ValueT, PortT> Parity;
      typedef cutl::Bitfield<6, 6, ValueT, PortT> Break;
      typedef cutl::Bitfield<7, 7, ValueT, PortT> Dlab;
   };
};

// Access LCR register in UART 0 as an 8-bit word
Uart<0>::Lcr() = 0x12;
uint8_t a = Uart<0>::Lcr();

// Access the Data bitfield of the LCR register of UART 1, where the channel
// is determined at run-time.
Uart::Lcr::Data(1) = 1;
uint8_t b = Uart::Lcr::Data(1);

Uart::Lcr::Data(1) = 1;

/*--------------------------------END OF FILE -------------------------------*/
