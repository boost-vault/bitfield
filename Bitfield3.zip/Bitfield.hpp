/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#ifndef BITFIELD_HPP
#define BITFIELD_HPP

#include <stdint.h>
#include <cstddef>
#include <boost/static_assert.hpp>
#include <boost/type_traits.hpp>
#include <cassert>
#include "BitProxy.hpp"

//------------------------------------------------------------------------------
//! Portable bitfield
/*!
   Used to easily manipulate groups of bits the same way as does C bitfields,
   but in a portable manner.
   \par Example declaration:
   \code
namespace Rgb565
{
   typedef volatile uint16_t ValueT;
   typedef cutl::Bitfield<0, 4, ValueT> Red;
   typedef cutl::Bitfield<5, 10, ValueT> Green;
   typedef cutl::Bitfield<11, 15, ValueT> Blue;
};
   \endcode
   \par Example usage:
   \code
Rgb565::ValueT c = 0xffff;

// "Dynamic" write/read
Rgb565::Red red(c);
red = 23;
cout << red;

// "Static" write/read
Rgb565::Red::set(c, 23);
cout << Rgb565::Red::get(c);

// Access a bit within a bit field
bool bit = Rgb565::Green(c)[3];
   \endcode
   \note Bitfields within the same word may overlap.
   \param F    Position of the first bit (0 is the least significant bit)
   \param L    Position of the last bit (0 is the least significant bit)
   \param T    Unsigned integer type of the word occupied by the bitfield
   \param R    Reference type of the word occupied by the bitfield
   \param I    Type of the value used to initialize the reference  */
//------------------------------------------------------------------------------
template <uint8_t F, uint8_t L, class T, class R=T&, class I=T&>
class Bitfield
{
private:
   BOOST_STATIC_ASSERT( F < 8*sizeof(T) );
   BOOST_STATIC_ASSERT( L < 8*sizeof(T) );
   BOOST_STATIC_ASSERT( F <= L );

public:
   typedef T ValueT;
   typedef R ReferenceT;
   typedef I InitT;

   //! Useful constants
   enum
   {
      FIRST       = F,                 //!< Position of the first bit
      LAST        = L,                 //!< Position of the last bit
      WIDTH       = LAST - FIRST + 1,  //!< Width in bits of the bitfield
      VAL_MASK    = (1 << WIDTH) - 1,  //!< Mask applied against assigned values
      FIELD_MASK  = VAL_MASK << FIRST  //!< Mask of the field's bit positions
   };

   Bitfield() {}
   explicit Bitfield(I init) : ref_(init) {}

   //! Dynamic write of a bitfield
   Bitfield& operator=(T val)
   {
      ref_ = (ref_ & ~FIELD_MASK) | ((val & VAL_MASK) << FIRST);
      return *this;
   }

   //! Dynamic read of a bitfield
   operator T() const {return (ref_ & FIELD_MASK) >> FIRST;}

   //! Returns the inverted bitfield value.
   T operator~() const {return (~ref_ & FIELD_MASK) >> FIRST;}

   //! Accesses a single bit within the bitfield
   /*! Non-constant access. Index 0 = least significant bit */
   BitProxy<T, R> operator[](std::size_t index)
   {
      assert(index < WIDTH);
      return BitProxy<T, R>(ref_, FIRST + index);
   }

   //! Accesses a single bit within the bitfield
   /*! Constant access. Index 0 = least significant bit */
   BitProxy<T, const R> operator[](std::size_t index) const
   {
      assert(index < WIDTH);
      return BitProxy<T, const R>(ref_, FIRST + index);
   }

   //! Returns the current bitfield value as bit flags.
   /*! The returned bit flags can be ORed with other bit flags. */
   T flags() const
   {
      return ref_ & FIELD_MASK;
   }

   //! Returns the given bitfield value as bit flags.
   /*! The returned bit flags can be ORed with other bit flags. */
   static T flags(T val) {return (val & VAL_MASK) << FIRST;}

   //! Static write of a bitfield
   static void set(T val)
      {R ref; ref = (ref & ~FIELD_MASK) | ((val & VAL_MASK) << FIRST);}

   //! Static write of a bitfield, with reference initializer
   template <class U>
   static void set(U& init, T val)
      {R ref(init); ref = (ref & ~FIELD_MASK) | ((val & VAL_MASK) << FIRST);}

   //! Static read of a bitfield
   static T get() {return (R() & FIELD_MASK) >> FIRST;}

   //! Static read of a bitfield, with reference initializer
   template <class U>
   static T get(const U& init) {return (R(init) & FIELD_MASK) >> FIRST;}

   // Arithmetic-assign operators

   Bitfield& operator++() {return *this += 1;}

   T operator++(int) {T ret(*this); ++*this; return ret;}

   Bitfield& operator--() {return *this -= 1;}

   T operator--(int) {T ret(*this); --*this; return ret;}

   Bitfield& operator+=(T rhs) {return *this = *this + rhs;}

   Bitfield& operator-=(T rhs) {return *this = *this - rhs;}

   Bitfield& operator*=(T rhs) {return *this = *this*rhs;}

   Bitfield& operator/=(T rhs) {return *this = *this/rhs;}

   Bitfield& operator%=(T rhs) {return *this = *this%rhs;}

   Bitfield& operator<<=(int rhs) {return *this = *this << rhs;}

   Bitfield& operator>>=(int rhs) {return *this = *this >> rhs;}

   Bitfield& operator&=(T rhs) {return *this = *this & rhs;}

   Bitfield& operator|=(T rhs) {return *this = *this | rhs;}

   Bitfield& operator^=(T rhs) {return *this = *this ^ rhs;}

private:
   R ref_;
};

#endif // #ifndef BITFIELD_HPP

/*--------------------------------END OF FILE -------------------------------*/
