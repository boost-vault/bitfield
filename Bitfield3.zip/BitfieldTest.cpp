/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#include <iostream>
#include "Bitfield.hpp"

#define TS_ASSERT(c) assert((c))
#define TS_ASSERT_EQUALS(lhs,rhs) assert((lhs)==(rhs))

namespace
{
   typedef volatile uint16_t T;
   typedef Bitfield<8, 15, T> high;
   typedef Bitfield<4, 11, T> mid; // Intentionally overlap
   typedef Bitfield<0,  7, T> low;
   typedef Bitfield<0, 15, T> all;
   typedef Bitfield<4,  4, T> single;
   T r;
}

//-----------------------------------------------------------------------------
void testAssign()
{
   // Both dynamic and static write are tested here.
   r = 0;
   (high(r)) = 0x12;
   TS_ASSERT_EQUALS(r, 0x1200);
   low::set(r, 0x34);
   TS_ASSERT_EQUALS(r, 0x1234);
   (mid(r)) = 0xab;
   TS_ASSERT_EQUALS(r, 0x1ab4);
   all::set(r, 0x4321);
   TS_ASSERT_EQUALS(r, 0x4321);
   (single(r)) = 1;
   TS_ASSERT_EQUALS(r, 0x4331);
}

//-----------------------------------------------------------------------------
void testGet()
{
   r = 0x1234;
   TS_ASSERT_EQUALS(high(r), 0x12);
   TS_ASSERT_EQUALS(high::get(r), 0x12);
   TS_ASSERT_EQUALS(low(r), 0x34);
   TS_ASSERT_EQUALS(low::get(r), 0x34);
   TS_ASSERT_EQUALS(mid(r), 0x23);
   TS_ASSERT_EQUALS(mid::get(r), 0x23);
   TS_ASSERT_EQUALS(all(r), 0x1234);
   TS_ASSERT_EQUALS(all::get(r), 0x1234);
   TS_ASSERT_EQUALS(single(r), 1);
   TS_ASSERT_EQUALS(single::get(r), 1);
   TS_ASSERT_EQUALS(r, 0x1234);
   r = 0x1204;
   TS_ASSERT_EQUALS(single(r), 0);
   TS_ASSERT_EQUALS(single(r), 0);
}

//-----------------------------------------------------------------------------
void testFlags()
{
   r = 0x1234;
   TS_ASSERT_EQUALS(high(r).flags(), 0x1200);
   TS_ASSERT_EQUALS(mid(r).flags(), 0x0230);
   TS_ASSERT_EQUALS(low(r).flags(), 0x0034);
   TS_ASSERT_EQUALS(all(r).flags(), 0x1234);
   TS_ASSERT_EQUALS(single(r).flags(), 0x0010);
   TS_ASSERT_EQUALS(r, 0x1234);

   r = 0xffff;
   TS_ASSERT_EQUALS(high::flags(0x12), 0x1200);
   TS_ASSERT_EQUALS(mid::flags(0x34), 0x0340);
   TS_ASSERT_EQUALS(low::flags(0x56), 0x0056);
   TS_ASSERT_EQUALS(all::flags(0xabcd), 0xabcd);
   TS_ASSERT_EQUALS(single::flags(0), 0);
   TS_ASSERT_EQUALS(single::flags(1), 0x0010);
   TS_ASSERT_EQUALS(r, 0xffff);

   typedef uint16_t T;
   TS_ASSERT_EQUALS(high::flags(0x12), 0x1200);
   TS_ASSERT_EQUALS(mid::flags(0x34), 0x0340);
   TS_ASSERT_EQUALS(low::flags(0x56), 0x0056);
   TS_ASSERT_EQUALS(all::flags(0xabcd), 0xabcd);
   TS_ASSERT_EQUALS(single::flags(0), 0);
   TS_ASSERT_EQUALS(single::flags(1), 0x0010);
}

//-----------------------------------------------------------------------------
void testInvert()
{
   r = 0xa5c3;
   TS_ASSERT_EQUALS(~high(r), 0x5a);
   TS_ASSERT_EQUALS(~mid(r), 0xa3);
   TS_ASSERT_EQUALS(~low(r), 0x3c);
   TS_ASSERT_EQUALS(~all(r), 0x5a3c);
   TS_ASSERT_EQUALS(~single(r), 1);
   TS_ASSERT_EQUALS(r, 0xa5c3);
   r = 0xffff;
   TS_ASSERT_EQUALS(~single(r), 0);
   TS_ASSERT_EQUALS(r, 0xffff);
}

//-----------------------------------------------------------------------------
void testTraits()
{
   typedef uint8_t T;
   TS_ASSERT((Bitfield<0, 0, T>::FIRST) == 0);
   TS_ASSERT((Bitfield<3, 5, T>::FIRST) == 3);
   TS_ASSERT((Bitfield<7, 7, T>::FIRST) == 7);

   TS_ASSERT((Bitfield<0, 0, T>::LAST) == 0);
   TS_ASSERT((Bitfield<3, 5, T>::LAST) == 5);
   TS_ASSERT((Bitfield<7, 7, T>::LAST) == 7);

   TS_ASSERT((Bitfield<0, 0, T>::WIDTH) == 1);
   TS_ASSERT((Bitfield<4, 7, T>::WIDTH) == 4);
   TS_ASSERT((Bitfield<0, 7, T>::WIDTH) == 8);

   TS_ASSERT((Bitfield<0, 0, T>::VAL_MASK) == 0x01);
   TS_ASSERT((Bitfield<4, 4, T>::VAL_MASK) == 0x01);
   TS_ASSERT((Bitfield<1, 3, T>::VAL_MASK) == 0x07);
   TS_ASSERT((Bitfield<7, 7, T>::VAL_MASK) == 0x01);
   TS_ASSERT((Bitfield<0, 7, T>::VAL_MASK) == 0xff);

   TS_ASSERT((Bitfield<0, 0, T>::FIELD_MASK) == 0x01);
   TS_ASSERT((Bitfield<0, 3, T>::FIELD_MASK) == 0x0f);
   TS_ASSERT((Bitfield<4, 7, T>::FIELD_MASK) == 0xf0);
   TS_ASSERT((Bitfield<7, 7, T>::FIELD_MASK) == 0x80);
   TS_ASSERT((Bitfield<0, 7, T>::FIELD_MASK) == 0xff);
}

//-----------------------------------------------------------------------------
template <class B>
void doBitAccessTest_(B bf)
{
   // Manually set and clear each bit (using r) in the bitfield and verify
   // that the changes are reflected while reading bf[i].
   // Test bit inversion at the same time.
   for (int i=0; i<B::WIDTH; ++i)
   {
      r = 1 << (B::FIRST + i);
      TS_ASSERT_EQUALS(bf[i], true);
      TS_ASSERT_EQUALS(~bf[i], false);

      r = ~ (1 << (B::FIRST + i));
      TS_ASSERT_EQUALS(bf[i], false);
      TS_ASSERT_EQUALS(~bf[i], true);
   }

   // Set and clear bf[i] and verify that the changes are reflected while
   // reading r.
   for (int i=0; i<B::WIDTH; ++i)
   {
      r = 0;
      bf[i] = 1;
      TS_ASSERT_EQUALS(r, 1 << (B::FIRST + i));

      r = 0xffff;
      bf[i] = 0;
      TS_ASSERT_EQUALS( r, uint16_t(~(1u << (B::FIRST + i))) );
   }
}

//-----------------------------------------------------------------------------
void testBitAccess()
{
   doBitAccessTest_(high(r));
   doBitAccessTest_(mid(r));
   doBitAccessTest_(low(r));
   doBitAccessTest_(all(r));
   doBitAccessTest_(single(r));
}

//-----------------------------------------------------------------------------
void testOperators()
{
   r = 0;
   (mid(r)) = 1;
   T val;
   T mask = mid::VAL_MASK;
   val = mid(r);
   TS_ASSERT_EQUALS(++mid(r),   (++val & mask) );
   TS_ASSERT_EQUALS(--mid(r),   (--val & mask) );

   TS_ASSERT_EQUALS(mid(r)++,   (val++ & mask) );
   TS_ASSERT_EQUALS(mid(r),     (val & mask) );

   TS_ASSERT_EQUALS(mid(r)--,   (val-- & mask) );
   TS_ASSERT_EQUALS(mid(r),     (val & mask) );

   TS_ASSERT_EQUALS(mid(r)+=1,  (val+=1 & mask) );
   TS_ASSERT_EQUALS(mid(r)-=1,  (val-=1 & mask) );
   TS_ASSERT_EQUALS(mid(r)*=24,  (val*=24 & mask) );
   TS_ASSERT_EQUALS(mid(r)/=3,  (val/=3 & mask) );
   TS_ASSERT_EQUALS(mid(r)%=5,  (val%=5 & mask) );
   TS_ASSERT_EQUALS(mid(r)&=9,  (val&=9 & mask) );
   TS_ASSERT_EQUALS(mid(r)|=9,  (val|=9 & mask) );
   TS_ASSERT_EQUALS(mid(r)^=6,  (val^=6 & mask) );

   //Expected after previous manipulations.
   TS_ASSERT_EQUALS(mid(r), 0x0f);

   TS_ASSERT_EQUALS(mid(r)<<=1, (val<<=1 & mask) );
   TS_ASSERT_EQUALS(mid(r)>>=1, (val>>=1 & mask) );

   //Assert that overflow doesn't affect the non-overlapped higher and lower
   //bits of the register.
   (mid(r)) = 0xff;
   val = mid(r);
   TS_ASSERT_EQUALS(++mid(r),   (++val & mask) );

   (mid(r)) = 0x00;
   val = mid(r);
   TS_ASSERT_EQUALS(--mid(r),   (--val & mask) );

   //Assert that bits other than the mid bits arent't modified.
   TS_ASSERT_EQUALS(r & ~mid::FIELD_MASK, 0x0000);
}

//-----------------------------------------------------------------------------
int main(int argc, char* argv[])
{
   std::cout << "Testing Bitfield...\n";
   testAssign();
   testGet();
   testFlags();
   testInvert();
   testTraits();
   testBitAccess();
   testOperators();
   std::cout << "All tests successful\n";
   return 0;
}

/*--------------------------------END OF FILE -------------------------------*/
