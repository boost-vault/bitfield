/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#ifndef PORT_HPP
#define PORT_HPP

#include <cstddef>

//! Integer type used as a Port address
typedef std::size_t PortAddr;

//-----------------------------------------------------------------------------
//! Memory-mapped I/O port access
/*!
   Example usage:
   \code
// Declaration of I/O register including bitfields
template <std::size_t C = 0>
struct Uart
{
   typedef uint8_t ValueT;
   enum
   {
      BASE = 0x000002e8 + C*0x10,
   };

   struct Lcr
   {
      enum {ADDR = BASE + 3};
      typedef Port<ValueT, ADDR> PortT;
      typedef cutl::Bitfield<0, 1, ValueT, PortT, PortT:AddrT> Data;
      typedef cutl::Bitfield<2, 2, ValueT, PortT, PortT:AddrT> Stop;
      typedef cutl::Bitfield<3, 5, ValueT, PortT, PortT:AddrT> Parity;
      typedef cutl::Bitfield<6, 6, ValueT, PortT, PortT:AddrT> Break;
      typedef cutl::Bitfield<7, 7, ValueT, PortT, PortT:AddrT> Dlab;
   };
};

// Access LCR register in UART 0 as an 8-bit word
Uart<0>::Lcr() = 0x12;           // "Dynamic" write
Uart<0>::Lcr::set(0x12);         // "Static" write
uint8_t a = Uart<0>::Lcr();      // "Dynamic" read
uint8_t b = Uart<0>::Lcr::get(); // "Static" read

// Access the Data bitfield of the LCR register of UART 1, where the channel
// is determined at run-time.
Uart::Lcr::Data(1) = 1;
uint8_t b = Uart::Lcr::Data(1);
   \endcode
   \param T Value type
   \param A Base address
   \param O Channel address offset
*/
template <class T, PortAddr B, PortAddr O = 0>
class Port
{
public:
   typedef T ValueT;       //!< Value type
   typedef PortAddr AddrT; //!< Address type

   enum
   {
      BASE = B,   //!< Base address
      OFFSET = O  //!< Offset between channels
   };

   //! Constructor
   explicit Port(PortAddr channel = 0) :  ptr_(makePtr_(channel)) {}

   //! Copy constructor
   Port(const Port& rhs) : ptr_(rhs.ptr_) {}

   //! Dynamic write to port
   Port& operator=(ValueT rhs) {*ptr_ = rhs; return *this;}

   //! Dynamic read from port
   operator ValueT() const {return *ptr_;}

   //! Read from port and return inverted bits
   ValueT operator~() const {return ~*ptr_;}

   //! Logically AND port bits
   Port& operator&=(ValueT rhs) {*ptr_ &= rhs; return *this;}

   //! Logically OR port bits
   Port& operator|=(ValueT rhs) {*ptr_ |= rhs; return *this;}

   //! Logically XOR port bits
   Port& operator^=(ValueT rhs) {*ptr_ ^= rhs; return *this;}

   //! Static write to port base address
   static void set(T val) {write(0, val);}

   //! Static write to port channel
   static void set(PortAddr channel, T val) {*makePtr_(channel) = val;}

   //! Static read from port base address, or port channel if specified
   static T get(PortAddr channel = 0) {return *makePtr_(channel);}

private:
   static volatile T* makePtr_(PortAddr channel)
   {
      return reinterpret_cast<volatile T*>(BASE + OFFSET*channel);
   }

   volatile T* ptr_;
};

#endif   // #ifndef PORT_HPP

/*--------------------------------END OF FILE -------------------------------*/
