/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#include <iostream>
#include <stdint.h>
#include "Bitfield.hpp"
#include "Port.hpp"

#define TS_ASSERT(c) assert((c))
#define TS_ASSERT_EQUALS(lhs,rhs) assert((lhs)==(rhs))

//-----------------------------------------------------------------------------
template <class T, PortAddr B>
void doReadWriteTest_()
{
   typedef Port<T, B, 1> PortT;
   T buf[2] = {0};
   const PortAddr addr0 =  reinterpret_cast<PortAddr>(buf) -
                                 PortT::BASE;
   const PortAddr addr1 =  addr0 + sizeof(T);
   PortT p0(addr0);
   PortT p1(addr1);

   p0 = 123u;
   p1 = 234u;
   TS_ASSERT_EQUALS(buf[0], 123u);
   TS_ASSERT_EQUALS(buf[1], 234u);
   TS_ASSERT_EQUALS(p0, 123u);
   TS_ASSERT_EQUALS(p1, 234u);

   PortT::set(addr0, 234u);
   PortT::set(addr1, 123u);
   TS_ASSERT_EQUALS(buf[0], 234u);
   TS_ASSERT_EQUALS(buf[1], 123u);
   TS_ASSERT_EQUALS(PortT::get(addr0), 234u);
   TS_ASSERT_EQUALS(PortT::get(addr1), 123u);
}

//-----------------------------------------------------------------------------
void testReadWrite()
{
   doReadWriteTest_<uint8_t, 0>();
   doReadWriteTest_<uint8_t, 1>();
   doReadWriteTest_<uint16_t, 0>();
   doReadWriteTest_<uint16_t, 1>();
   doReadWriteTest_<uint32_t, 0>();
   doReadWriteTest_<uint32_t, 1>();
}

//-----------------------------------------------------------------------------
template <class T>
void doBitwiseTest_()
{
   typedef Port<T, 0, 1> PortT;
   T val = 0;
   PortT p(reinterpret_cast<PortAddr>(&val));

   p |= 0x5a;
   TS_ASSERT_EQUALS(val, 0x5a);
   p &= 0xf0;
   TS_ASSERT_EQUALS(val, 0x50);
   p ^= 0xff;
   TS_ASSERT_EQUALS(val, 0xaf);
   TS_ASSERT_EQUALS((T)~p, (T)~val);
}

//-----------------------------------------------------------------------------
void testBitwise()
{
   doBitwiseTest_<uint8_t>();
   doBitwiseTest_<uint16_t>();
   doBitwiseTest_<uint32_t>();
}

//-----------------------------------------------------------------------------
void testBitfield()
{
   typedef uint16_t ValueT;
   typedef Port<ValueT, 0, 1> PortT;
   typedef Bitfield<0, 7, ValueT, PortT, PortT::AddrT> Low;
   typedef Bitfield<4, 11, ValueT, PortT, PortT::AddrT> Mid;
   typedef Bitfield<8, 15, ValueT, PortT, PortT::AddrT> High;

   ValueT v = 0;
   PortT::AddrT ch = reinterpret_cast<PortT::AddrT>(&v);

   High::set(ch, 0x12);
   TS_ASSERT_EQUALS(v, 0x1200);
   Low::set(ch, 0x34);
   TS_ASSERT_EQUALS(v, 0x1234);
   Mid::set(ch, 0xab);
   TS_ASSERT_EQUALS(v, 0x1ab4);

   v = 0x1234;
   TS_ASSERT_EQUALS(High::get(ch), 0x12);
   TS_ASSERT_EQUALS(Low::get(ch), 0x34);
   TS_ASSERT_EQUALS(Mid::get(ch), 0x23);
   TS_ASSERT_EQUALS(v, 0x1234);
}

int main(int argc, char* argv[])
{
   std::cout << "Testing Port...\n";
   testReadWrite();
   testBitwise();
   std::cout << "All tests successful\n";
   return 0;
}

/*--------------------------------END OF FILE -------------------------------*/
