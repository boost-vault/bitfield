/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#ifndef BITFIELD_HPP
#define BITFIELD_HPP

#include <cstddef>
#include <boost/static_assert.hpp>

//-----------------------------------------------------------------------------
template <class T, class R>
class bit_proxy
{
public:
   bit_proxy& operator=(bool state)
   {
      field_ = (field_ & ~(1 << index_)) | (state << index_);
      return *this;
   }

   operator bool() const {return (field_ & (1 << index_)) != 0;}

   bool operator~() const {return !(static_cast<bool>(*this));}

private:
   R field_;
   const std::size_t index_;

   bit_proxy(R field, std::size_t index) : field_(field), index_(index) {}

   template <class, int, int> friend class bitfield;
};


//------------------------------------------------------------------------------
template <class T, int F, int L>
class bitfield
{
private:
   BOOST_STATIC_ASSERT( F < 8*sizeof(T) );
   BOOST_STATIC_ASSERT( L < 8*sizeof(T) );
   BOOST_STATIC_ASSERT( F <= L );

   typedef bit_proxy<T, T&> RefT;
   typedef bit_proxy<T, const T&> ConstRefT;

public:
   enum
   {
      FIRST       = F,                 // Position of the first bit
      LAST        = L,                 // Position of the last bit
      WIDTH       = LAST - FIRST + 1,  // Width in bits of the bitfield
      VAL_MASK    = (1 << WIDTH) - 1,  // Mask applied against assigned values
      FIELD_MASK  = VAL_MASK << FIRST  // Mask of the field's bit positions
   };

   bitfield& operator=(T val)
   {
      field_ = (field_ & ~FIELD_MASK) | ((val & VAL_MASK) << FIRST);
      return *this;
   }

   operator T() const {return (field_ & FIELD_MASK) >> FIRST;}

   T operator~() const {return (~field_ & FIELD_MASK) >> FIRST;}

   RefT operator[](std::size_t index)
   {
      return RefT(field_, FIRST + index);
   }

   ConstRefT operator[](std::size_t index) const
   {
      return ConstRefT(field_, FIRST + index);
   }

   T operator()() const {return field_ & FIELD_MASK;}

   T operator()(T val) const {return flags(val);}

   static T flags(T val) {return (val & VAL_MASK) << FIRST;}

   std::size_t first() const {return FIRST;}

   std::size_t last() const {return LAST;}

   std::size_t width() const {return WIDTH;}

   T valMask() const {return VAL_MASK;}

   T fieldMask() const {return FIELD_MASK;}

   bitfield& operator++() {*this += 1; return *this;}

   bitfield operator++(int) {bitfield ret = *this; ++*this; return ret;}

   bitfield& operator--() {*this -= 1; return *this;}

   bitfield operator--(int) {bitfield ret = *this; --*this; return ret;}

   bitfield& operator+=(T rhs) {*this = (T)*this + rhs; return *this;}

   bitfield& operator-=(T rhs) {*this = (T)*this - rhs; return *this;}

   bitfield& operator*=(T rhs) {*this = (T)*this*rhs; return *this;}

   bitfield& operator/=(T rhs) {*this = (T)*this/rhs; return *this;}

   bitfield& operator%=(T rhs) {*this = (T)*this%rhs; return *this;}

   bitfield& operator<<=(int rhs) {*this = (T)*this << rhs; return *this;}

   bitfield& operator>>=(int rhs) {*this = (T)*this >> rhs; return *this;}

   bitfield& operator&=(T rhs) {*this = (T)*this & rhs; return *this;}

   bitfield& operator|=(T rhs) {*this = (T)*this | rhs; return *this;}

   bitfield& operator^=(T rhs) {*this = (T)*this ^ rhs; return *this;}

private:
   T field_;
};

#endif // #ifndef BITFIELD_HPP

