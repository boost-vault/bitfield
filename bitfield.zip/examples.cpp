/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

//------------------------------------------------------------------------------
// EXAMPLE DECLARATION

union LineControlRegister
{
   typedef uint8_t T;
   T word;  // Access the register as an 8-bit word
   bitfield<T, 0, 1> data;
   bitfield<T, 2, 2> stop;
   bitfield<T, 3, 5> parity;
   bitfield<T, 6, 6> break;
   bitfield<T, 7, 7> dlab;
};

// NOTE: Bitfields within the same word may overlap

//------------------------------------------------------------------------------
// EXAMPLE USAGE

// Create a reference that will access address 0x403 on an embedded system
volatile LineControlRegister& lcr =
   *(reinterpret_cast<volatile LineControlRegister*>(0x403));

// Initialize all fields at once. If optimization is enabled, the compiler
// should generate a single memory load instruction.
lcr.word =  lcr.data(3) | lcr.stop(0) | lcr.parity(0) |
            lcr.break(0) | lcr.dlab(0);

// Bitfield access examples
lcr.parity = 2;               // Write to a bitfield
uint8_t parity = lcr.parity;  // Read from a bitfield. Result should be 2.
lcd.data[1] = true;           // Accesses bit 1 within the "data" field.

//------------------------------------------------------------------------------
// COLOR EXAMPLE:

struct rgb16
{
   typedef uint16_t word_t;

   rgb16() : word(0) {}

   rgb16(word_t red, word_t green, word_t blue)
   :  word(red_(red) | green_(green) | blue_(blue)) {}

   void set_rgb(word_t red, word_t green, word_t blue)
   {
      red_ = red; green_ = green; blue_ = blue;
   }

   word_t red() {return red_;}
   word_t green() {return green_;}
   word_t blue() {return blue_;}

private:
   union
   {
      word_t word_;
      bitfield<word_t, 0, 4> red_;
      bitfield<word_t, 5, 10> green_;
      bitfield<word_t, 11, 15> blue_;
   };
};

