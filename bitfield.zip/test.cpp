/*-----------------------------------------------------------------------------
(c) 2006 Emile Cormier

The author has placed this work in the Public Domain. Everyone is free to use,
modify, or distribute this work without prior consent from anybody.

This work is provided on an "as is" basis, without warranty of any
kind. Use at your own risk! Under no circumstances shall the author(s) or
contributor(s) be liable for damages resulting directly or indirectly from the
use or non-use of this work.
-----------------------------------------------------------------------------*/

#include <stdint.h>
#include <iostream>
#include <cassert>
#include "bitfield.hpp"

#define ASSERT_EQUALS(a,b) assert((a) == (b))
#define ASSERT(a) assert((a))

union Register
{
   typedef uint16_t T;
   T word;
   bitfield<T, 8, 15>   high;
   bitfield<T, 4, 11>   mid; // Intentionally overlap
   bitfield<T, 0, 7>    low;
   bitfield<T, 0, 15>   all;
   bitfield<T, 4, 4>    single;
};

namespace
{
   Register r;
}

//-----------------------------------------------------------------------------
void testAssign()
{
   r.word = 0;
   r.high = 0x12;
   ASSERT_EQUALS(r.word, 0x1200);
   r.low = 0x34;
   ASSERT_EQUALS(r.word, 0x1234);
   r.mid = 0xab;
   ASSERT_EQUALS(r.word, 0x1ab4);
   r.all = 0x4321;
   ASSERT_EQUALS(r.word, 0x4321);
   r.single = 1;
   ASSERT_EQUALS(r.word, 0x4331);
}

//-----------------------------------------------------------------------------
void testGet()
{
   r.word = 0x1234;
   ASSERT_EQUALS(r.high, 0x12);
   ASSERT_EQUALS(r.low, 0x34);
   ASSERT_EQUALS(r.mid, 0x23);
   ASSERT_EQUALS(r.all, 0x1234);
   ASSERT_EQUALS(r.single, 1);
   ASSERT_EQUALS(r.word, 0x1234);
   r.word = 0x1204;
   ASSERT_EQUALS(r.single, 0);
}

//-----------------------------------------------------------------------------
void testFlags()
{
   r.word = 0x1234;
   ASSERT_EQUALS(r.high(), 0x1200);
   ASSERT_EQUALS(r.mid(), 0x0230);
   ASSERT_EQUALS(r.low(), 0x0034);
   ASSERT_EQUALS(r.all(), 0x1234);
   ASSERT_EQUALS(r.single(), 0x0010);
   ASSERT_EQUALS(r.word, 0x1234);

   r.word = 0xffff;
   ASSERT_EQUALS(r.high(0x12), 0x1200);
   ASSERT_EQUALS(r.mid(0x34), 0x0340);
   ASSERT_EQUALS(r.low(0x56), 0x0056);
   ASSERT_EQUALS(r.all(0xabcd), 0xabcd);
   ASSERT_EQUALS(r.single(0), 0);
   ASSERT_EQUALS(r.single(1), 0x0010);
   ASSERT_EQUALS(r.word, 0xffff);

   typedef uint16_t T;
   ASSERT_EQUALS((bitfield<T, 8, 15>::flags(0x12)), 0x1200);
   ASSERT_EQUALS((bitfield<T, 4, 11>::flags(0x34)), 0x0340);
   ASSERT_EQUALS((bitfield<T, 0, 7>::flags(0x56)), 0x0056);
   ASSERT_EQUALS((bitfield<T, 0, 15>::flags(0xabcd)), 0xabcd);
   ASSERT_EQUALS((bitfield<T, 4, 4>::flags(0)), 0);
   ASSERT_EQUALS((bitfield<T, 4, 4>::flags(1)), 0x0010);
}

//-----------------------------------------------------------------------------
void testInvert()
{
   r.word = 0xa5c3;
   ASSERT_EQUALS(~r.high, 0x5a);
   ASSERT_EQUALS(~r.mid, 0xa3);
   ASSERT_EQUALS(~r.low, 0x3c);
   ASSERT_EQUALS(~r.all, 0x5a3c);
   ASSERT_EQUALS(~r.single, 1);
   ASSERT_EQUALS(r.word, 0xa5c3);
   r.word = 0xffff;
   ASSERT_EQUALS(~r.single, 0);
   ASSERT_EQUALS(r.word, 0xffff);
}

//-----------------------------------------------------------------------------
void testTraits()
{
   typedef uint8_t T;
   ASSERT_EQUALS((bitfield<T, 0, 0>::FIRST), 0);
   ASSERT_EQUALS((bitfield<T, 3, 5>::FIRST), 3);
   ASSERT_EQUALS((bitfield<T, 7, 7>::FIRST), 7);

   ASSERT_EQUALS((bitfield<T, 0, 0>::LAST), 0);
   ASSERT_EQUALS((bitfield<T, 3, 5>::LAST), 5);
   ASSERT_EQUALS((bitfield<T, 7, 7>::LAST), 7);

   ASSERT_EQUALS((bitfield<T, 0, 0>::WIDTH), 1);
   ASSERT_EQUALS((bitfield<T, 4, 7>::WIDTH), 4);
   ASSERT_EQUALS((bitfield<T, 0, 7>::WIDTH), 8);

   ASSERT_EQUALS((bitfield<T, 0, 0>::VAL_MASK), 0x01);
   ASSERT_EQUALS((bitfield<T, 4, 4>::VAL_MASK), 0x01);
   ASSERT_EQUALS((bitfield<T, 1, 3>::VAL_MASK), 0x07);
   ASSERT_EQUALS((bitfield<T, 7, 7>::VAL_MASK), 0x01);
   ASSERT_EQUALS((bitfield<T, 0, 7>::VAL_MASK), 0xff);

   ASSERT_EQUALS((bitfield<T, 0, 0>::FIELD_MASK), 0x01);
   ASSERT_EQUALS((bitfield<T, 0, 3>::FIELD_MASK), 0x0f);
   ASSERT_EQUALS((bitfield<T, 4, 7>::FIELD_MASK), 0xf0);
   ASSERT_EQUALS((bitfield<T, 7, 7>::FIELD_MASK), 0x80);
   ASSERT_EQUALS((bitfield<T, 0, 7>::FIELD_MASK), 0xff);
}

//-----------------------------------------------------------------------------
template <class B>
void doBitAccessTest_(B& bf, const B& cbf)
{
   // Manually set and clear each bit (using r.word) in the bitfield and verify
   // that the changes are reflected while reading bf[i].
   // Also test bit inversion and constant access at the same time.
   for (int i=0; i<B::WIDTH; ++i)
   {
      r.word = 1u << (B::FIRST + i);
      ASSERT_EQUALS(cbf[i], true);
      ASSERT_EQUALS(~cbf[i], false);

      r.word = ~ (1u << (B::FIRST + i));
      ASSERT_EQUALS(bf[i], false);
      ASSERT_EQUALS(~cbf[i], true);
   }

   // Set and clear bf[i] and verify that the changes are reflected while
   // reading r.word.
   for (int i=0; i<B::WIDTH; ++i)
   {
      r.word = 0;
      bf[i] = 1u;
      ASSERT_EQUALS(r.word, 1u << (B::FIRST + i));

      r.word = 0xffff;
      bf[i] = 0;
      ASSERT_EQUALS( r.word, (uint16_t)(~(1u << (B::FIRST + i))) );
   }
}

//-----------------------------------------------------------------------------
void testBitAccess()
{
   const Register& cr = r;
   doBitAccessTest_(r.high, cr.high);
   doBitAccessTest_(r.mid, cr.mid);
   doBitAccessTest_(r.low, cr.low);
   doBitAccessTest_(r.all, cr.all);
   doBitAccessTest_(r.single, cr.single);
}

//-----------------------------------------------------------------------------
int main(int argc, char *argv[])
{
   testAssign();
   testGet();
   testFlags();
   testInvert();
   testTraits();
   testBitAccess();
   std::cout << "All tests successful!\n";
   return 0;
}

